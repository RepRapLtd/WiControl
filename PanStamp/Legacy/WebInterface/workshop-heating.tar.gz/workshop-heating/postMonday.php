<?php

if (isset($HTTP_RAW_POST_DATA))
{
   file_put_contents("../../workshop-profile-monday.dat", $HTTP_RAW_POST_DATA);
   echo('Saved');
}
?>

