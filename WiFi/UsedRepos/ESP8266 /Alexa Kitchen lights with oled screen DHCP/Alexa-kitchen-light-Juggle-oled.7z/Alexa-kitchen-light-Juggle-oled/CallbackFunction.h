#ifndef CALLBACKFUNCTION_H
#define CALLBACKFUNCTION_H
 
#include <Arduino.h>

typedef void (*CallbackFunction) ();

#endif
